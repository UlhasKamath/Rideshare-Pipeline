
from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.bash import BashOperator
from airflow.providers.postgres.operators.postgres import PostgresOperator

default_args = {
    "owner": "airflow",
    "depends_on_past": False,
    "retries": 1,
    "retry_delay": timedelta(minutes=5)
}

with DAG(
    dag_id="batch_etl_daily",
    default_args=default_args,
    # start_date=datetime(2025, 8, 30),
    start_date=datetime.today(),
    schedule_interval="@daily",
    catchup=False,
    max_active_runs = 1,
    tags=["rideshare", "batch", "spark", "postgres"]
) as dag:
    
    truncate_gold = PostgresOperator(
        task_id="truncate_gold_tables",
        postgres_conn_id="rides_postgres",
        sql="""
            TRUNCATE TABLE gold.fact_payments CASCADE;
            TRUNCATE TABLE gold.fact_rides CASCADE;
            TRUNCATE TABLE gold.dim_riders CASCADE;
            TRUNCATE TABLE gold.dim_drivers CASCADE;
        """
    )


    bronze = BashOperator(
        task_id="bronze",
        bash_command=
        "docker exec spark-master "
        "/opt/bitnami/spark/bin/spark-submit "
        "--master spark://spark-master:7077 "
        "--packages org.apache.spark:spark-sql-kafka-0-10_2.12:3.5.1,org.postgresql:postgresql:42.7.3 "
        "/opt/spark/jobs/streaming_to_bronze.py "
        # "--run_mode once"
        ,
    )



    silver = BashOperator(
        task_id="run_silver_transform",
        bash_command=(
            "docker exec spark-master "
            "/opt/bitnami/spark/bin/spark-submit "
            "--master spark://spark-master:7077 "
            "--packages org.postgresql:postgresql:42.7.3 "
            "/opt/spark/jobs/batch_silver_transform.py"
        )
    )

    gold = BashOperator(
        task_id="build_star_schema",
        bash_command=(
            "docker exec spark-master "
            "/opt/bitnami/spark/bin/spark-submit "
            "--master spark://spark-master:7077 "
            "--packages org.postgresql:postgresql:42.7.3 "
            "/opt/spark/jobs/build_star_schema.py"
        )
    )
    

    dq_checks = PostgresOperator(
        task_id="dq_basic_checks",
        postgres_conn_id="rides_postgres",
        sql="""
        DO $$
        BEGIN
            -- Row count checks
            IF (SELECT COUNT(*) FROM silver.rides_cleaned) = 0 THEN
                RAISE EXCEPTION 'Data quality failed: silver.rides_cleaned is empty';
            END IF;

            IF (SELECT COUNT(*) FROM gold.fact_rides) = 0 THEN
                RAISE EXCEPTION 'Data quality failed: gold.fact_rides is empty';
            END IF;

            -- Schema validation (expected columns exist in fact_rides)
            IF NOT EXISTS (
                SELECT 1
                FROM information_schema.columns
                WHERE table_schema = 'gold' AND table_name = 'fact_rides'
                AND column_name IN ('ride_id', 'driver_id', 'rider_id', 'requested_at')
            ) THEN
                RAISE EXCEPTION 'Data quality failed: gold.fact_rides schema is missing expected columns';
            END IF;

            -- Duplicate detection (ride_id should be unique in fact_rides)
            IF EXISTS (
                SELECT ride_id
                FROM gold.fact_rides
                GROUP BY ride_id
                HAVING COUNT(*) > 1
            ) THEN
                RAISE EXCEPTION 'Data quality failed: Duplicate ride_id found in gold.fact_rides';
            END IF;

            -- Duplicate detection (payment_id should be unique in fact_payments)
            IF EXISTS (
                SELECT payment_id
                FROM gold.fact_payments
                GROUP BY payment_id
                HAVING COUNT(*) > 1
            ) THEN
                RAISE EXCEPTION 'Data quality failed: Duplicate payment_id found in gold.fact_payments';
            END IF;

        END
        $$;
        """
    )


    truncate_gold >>  bronze >> silver >> gold >> dq_checks
