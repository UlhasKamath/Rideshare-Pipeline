\connect rideshare;

CREATE SCHEMA IF NOT EXISTS bronze;
CREATE SCHEMA IF NOT EXISTS silver;
CREATE SCHEMA IF NOT EXISTS gold;


CREATE TABLE IF NOT EXISTS bronze.rides (
    ride_id TEXT,
    rider_id TEXT,
    rider_name TEXT,
    driver_id TEXT,
    pickup_lat DOUBLE PRECISION,
    pickup_lng DOUBLE PRECISION,
    dropoff_lat DOUBLE PRECISION,
    dropoff_lng DOUBLE PRECISION,
    requested_at TIMESTAMPTZ,
    status TEXT,
    ingestion_time TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS bronze.drivers (
    driver_id TEXT,
    driver_name TEXT,
    car_model TEXT,
    is_active BOOLEAN,
    updated_at TIMESTAMPTZ,
    ingestion_time TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS bronze.payments (
    payment_id TEXT,
    ride_id TEXT,
    amount NUMERIC(10,2),
    currency TEXT,
    method TEXT,
    paid_at TIMESTAMPTZ,
    ingestion_time TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS silver.rides_cleaned (
    ride_id TEXT PRIMARY KEY,
    rider_id TEXT,
    rider_name TEXT,
    driver_id TEXT,
    pickup_lat DOUBLE PRECISION,
    pickup_lng DOUBLE PRECISION,
    dropoff_lat DOUBLE PRECISION,
    dropoff_lng DOUBLE PRECISION,
    requested_at TIMESTAMPTZ,
    status TEXT
);

CREATE TABLE IF NOT EXISTS silver.drivers_latest (
    driver_id TEXT PRIMARY KEY,
    driver_name TEXT,
    car_model TEXT,
    is_active BOOLEAN,
    updated_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS silver.payments_cleaned (
    payment_id TEXT PRIMARY KEY,
    ride_id TEXT,
    amount NUMERIC(10,2),
    currency TEXT,
    method TEXT,
    paid_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS gold.dim_drivers (
    driver_id TEXT PRIMARY KEY,
    driver_name TEXT,
    car_model TEXT,
    is_active BOOLEAN
);

CREATE TABLE IF NOT EXISTS gold.dim_riders (
    rider_id TEXT PRIMARY KEY,
    rider_name TEXT
);

CREATE TABLE IF NOT EXISTS gold.fact_rides (
    ride_id TEXT PRIMARY KEY,
    driver_id TEXT REFERENCES gold.dim_drivers(driver_id),
    rider_id TEXT REFERENCES gold.dim_riders(rider_id),
    requested_at TIMESTAMPTZ,
    status TEXT,
    pickup_lat DOUBLE PRECISION,
    pickup_lng DOUBLE PRECISION,
    dropoff_lat DOUBLE PRECISION,
    dropoff_lng DOUBLE PRECISION
);

CREATE TABLE IF NOT EXISTS gold.fact_payments (
    payment_id TEXT PRIMARY KEY,
    ride_id TEXT REFERENCES gold.fact_rides(ride_id),
    amount NUMERIC(10,2),
    currency TEXT,
    method TEXT,
    paid_at TIMESTAMPTZ
);
