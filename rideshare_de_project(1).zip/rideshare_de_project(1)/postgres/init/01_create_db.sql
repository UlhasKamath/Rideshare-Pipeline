-- Create databases
CREATE DATABASE airflow;

-- Grant DB privileges
GRANT ALL PRIVILEGES ON DATABASE airflow TO rides;
GRANT ALL PRIVILEGES ON DATABASE rideshare TO rides;

-- Connect to airflow DB
\c airflow;

-- Transfer schema ownership and privileges
ALTER SCHEMA public OWNER TO rides;
GRANT ALL PRIVILEGES ON SCHEMA public TO rides;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO rides;

-- Ensure future objects are accessible
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL PRIVILEGES ON TABLES TO rides;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL PRIVILEGES ON SEQUENCES TO rides;
