
# Rideshare Data Platform (Local) — Kafka + Spark + Airflow + Postgres + Docker

End-to-end, resume-ready Data Engineering project run locally with Docker.

## Quickstart
1) `docker compose up -d --build`
2) `bash kafka/create_topics.sh`
3) New terminal:
```
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r kafka/producer/requirements.txt
python kafka/producer/produce_events.py --broker localhost:29092 --rate 2
```
4) Open UIs:
- Airflow: http://localhost:8080 (admin/admin)
- Kafka UI: http://localhost:8081
- Adminer: http://localhost:8082 (Server: postgres, User: rides, Pass: ridespwd, DB: rideshare)
5) Trigger DAG `batch_etl_daily` in Airflow.

## Files
- `airflow/dags/batch_etl.py`
- `spark/jobs/streaming_to_bronze.py`
- `spark/jobs/batch_silver_transform.py`
- `spark/jobs/build_star_schema.py`
- `postgres/init/01_init.sql`
- `kafka/producer/produce_events.py`
