import os
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, from_json, current_timestamp
from pyspark.sql.types import (
    StructType, StructField, StringType, DoubleType,
    TimestampType, BooleanType, DecimalType
)

# --- ENV ---
KAFKA_BOOTSTRAP = os.getenv("KAFKA_BROKER_INSIDE", "kafka:9092")
JDBC_URL = os.getenv("JDBC_URL", "jdbc:postgresql://postgres:5432/rideshare")
JDBC_USER = os.getenv("JDBC_USER", "rides")
JDBC_PASSWORD = os.getenv("JDBC_PASSWORD", "ridespwd")
STARTING_OFFSETS = os.getenv("STARTING_OFFSETS", "earliest").strip()

spark = (
    SparkSession.builder
    .appName("rideshare-streaming-to-bronze")
    .config("spark.sql.shuffle.partitions", "2")
    .getOrCreate()
)
spark.sparkContext.setLogLevel("WARN")

# ---------- schemas ----------
rides_schema = StructType([
    StructField("ride_id", StringType()),
    StructField("rider_id", StringType()),
    StructField("rider_name", StringType()),
    StructField("driver_id", StringType()),
    StructField("pickup_lat", DoubleType()),
    StructField("pickup_lng", DoubleType()),
    StructField("dropoff_lat", DoubleType()),
    StructField("dropoff_lng", DoubleType()),
    StructField("requested_at", TimestampType()),
    StructField("status", StringType())
])

drivers_schema = StructType([
    StructField("driver_id", StringType()),
    StructField("driver_name", StringType()),
    StructField("car_model", StringType()),
    StructField("is_active", BooleanType()),
    StructField("updated_at", TimestampType())
])

payments_schema = StructType([
    StructField("payment_id", StringType()),
    StructField("ride_id", StringType()),
    StructField("amount", DecimalType(10,2)),
    StructField("currency", StringType()),
    StructField("method", StringType()),
    StructField("paid_at", TimestampType())
])

# ---------- helper ----------
def stream_to_pg(topic, schema, table, checkpoint_dir):
    df = (spark.readStream
        .format("kafka")
        .option("kafka.bootstrap.servers", KAFKA_BOOTSTRAP)
        .option("subscribe", topic)
        .option("startingOffsets", STARTING_OFFSETS)
        .option("failOnDataLoss", "false")
        .load())

    parsed = (df.selectExpr("CAST(value AS STRING) as json_str")
        .select(from_json(col("json_str"), schema).alias("data"))
        .select("data.*")
        .withColumn("ingestion_time", current_timestamp()))

    return (parsed.writeStream
        .foreachBatch(lambda batch, eid: (
            batch.write
                .format("jdbc")
                .option("url", JDBC_URL)
                .option("dbtable", table)
                .option("user", JDBC_USER)
                .option("password", JDBC_PASSWORD)
                .option("driver", "org.postgresql.Driver")
                .mode("append")
                .save()
        ))
        .option("checkpointLocation", checkpoint_dir)
        .outputMode("append")
        .trigger(once=True)
        .start())

# ---------- launch all three ----------
q1 = stream_to_pg("rides", rides_schema, "bronze.rides", "/opt/spark/checkpoints/rides")
q2 = stream_to_pg("drivers", drivers_schema, "bronze.drivers", "/opt/spark/checkpoints/drivers")
q3 = stream_to_pg("payments", payments_schema, "bronze.payments", "/opt/spark/checkpoints/payments")

q1.awaitTermination()
q2.awaitTermination()
q3.awaitTermination()
