
import os
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, row_number
from pyspark.sql.window import Window

JDBC_URL = os.getenv("JDBC_URL", "jdbc:postgresql://postgres:5432/rideshare")
JDBC_USER = os.getenv("JDBC_USER", "rides")
JDBC_PASSWORD = os.getenv("JDBC_PASSWORD", "ridespwd")

spark = (SparkSession.builder.appName("rideshare-batch-silver-transform").getOrCreate())
spark.sparkContext.setLogLevel("WARN")

def read_table(table):
    return (spark.read
            .format("jdbc")
            .option("url", JDBC_URL)
            .option("dbtable", table)
            .option("user", JDBC_USER)
            .option("password", JDBC_PASSWORD)
            .option("driver", "org.postgresql.Driver")
            .load())

def write_table(df, table, mode="overwrite"):
    (df.write
       .format("jdbc")
       .option("url", JDBC_URL)
       .option("dbtable", table)
       .option("user", JDBC_USER)
       .option("password", JDBC_PASSWORD)
       .option("driver", "org.postgresql.Driver")
       .mode(mode)
       .save())

rides = read_table("bronze.rides")
drivers = read_table("bronze.drivers")
payments = read_table("bronze.payments")

rides_valid = rides.filter(
    (col("pickup_lat").between(-90, 90)) &
    (col("pickup_lng").between(-180, 180)) &
    (col("dropoff_lat").between(-90, 90)) &
    (col("dropoff_lng").between(-180, 180))
)

w = Window.partitionBy("ride_id").orderBy(col("requested_at").desc_nulls_last())
rides_dedup = (rides_valid
               .withColumn("rn", row_number().over(w))
               .filter(col("rn") == 1)
               .drop("rn", "ingestion_time"))

write_table(rides_dedup, "silver.rides_cleaned")

wd = Window.partitionBy("driver_id").orderBy(col("updated_at").desc_nulls_last())
drivers_latest = (drivers
                  .withColumn("rn", row_number().over(wd))
                  .filter(col("rn") == 1)
                  .drop("rn", "ingestion_time"))

write_table(drivers_latest, "silver.drivers_latest")

payments_cleaned = (payments
                    .withColumn("amount", col("amount").cast("decimal(10,2)"))
                    .filter(col("amount").isNotNull() & (col("amount") >= 0))
                    .drop("ingestion_time"))

write_table(payments_cleaned, "silver.payments_cleaned")
