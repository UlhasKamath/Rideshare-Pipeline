import os
from pyspark.sql import SparkSession
from pyspark.sql.functions import lit

# --- ENV ---
JDBC_URL = os.getenv("JDBC_URL", "jdbc:postgresql://postgres:5432/rideshare")
JDBC_USER = os.getenv("JDBC_USER", "rides")
JDBC_PASSWORD = os.getenv("JDBC_PASSWORD", "ridespwd")

spark = (
    SparkSession.builder
    .appName("rideshare-build-gold-star-schema")
    .getOrCreate()
)
spark.sparkContext.setLogLevel("WARN")

# ---------- helpers ----------
def read_table(table):
    return (
        spark.read
        .format("jdbc")
        .option("url", JDBC_URL)
        .option("dbtable", table)
        .option("user", JDBC_USER)
        .option("password", JDBC_PASSWORD)
        .option("driver", "org.postgresql.Driver")
        .load()
    )

def write_table(df, table):
    (
        df.write.format("jdbc")
        .option("url", JDBC_URL)
        .option("dbtable", table)
        .option("user", JDBC_USER)
        .option("password", JDBC_PASSWORD)
        .option("driver", "org.postgresql.Driver")
        .option("batchsize", 1000)
        .option("isolationLevel", "READ_COMMITTED")
        .mode("append")  # append ONLY (Airflow truncates first)
        .save()
    )
    print(f"✅ Wrote {df.count()} rows into {table}")

# ---------- Load silver layer ----------
rides = read_table("silver.rides_cleaned")
drivers = read_table("silver.drivers_latest")
payments = read_table("silver.payments_cleaned")

# ---------- Build gold dimensions ----------
dim_drivers = (
    drivers.select("driver_id", "driver_name", "car_model", "is_active")
    .dropDuplicates(["driver_id"])
)

dim_riders = (
    rides.select("rider_id", "rider_name")
    .dropDuplicates(["rider_id"])
)

# Add explicit “Unknown” placeholder rows
unknown_driver = spark.createDataFrame(
    [("Unknown", "Unknown", "Unknown", False)],
    ["driver_id", "driver_name", "car_model", "is_active"]
)
dim_drivers = dim_drivers.union(unknown_driver).dropDuplicates(["driver_id"])

unknown_rider = spark.createDataFrame(
    [("Unknown", "Unknown")],
    ["rider_id", "rider_name"]
)
dim_riders = dim_riders.union(unknown_rider).dropDuplicates(["rider_id"])

# Ensure any driver IDs from rides exist in dim_drivers
missing_drivers = rides.select("driver_id").distinct().join(dim_drivers, "driver_id", "left_anti")
if missing_drivers.count() > 0:
    driver_placeholders = (
        missing_drivers
        .withColumn("driver_name", lit("Unknown"))
        .withColumn("car_model", lit("Unknown"))
        .withColumn("is_active", lit(False))
    )
    dim_drivers = dim_drivers.union(driver_placeholders).dropDuplicates(["driver_id"])

# Ensure any rider IDs from rides exist in dim_riders
missing_riders = rides.select("rider_id").distinct().join(dim_riders, "rider_id", "left_anti")
if missing_riders.count() > 0:
    rider_placeholders = missing_riders.withColumn("rider_name", lit("Unknown"))
    dim_riders = dim_riders.union(rider_placeholders).dropDuplicates(["rider_id"])

# ---------- Write dimensions first ----------
write_table(dim_drivers, "gold.dim_drivers")
write_table(dim_riders, "gold.dim_riders")

# ---------- Build facts ----------
fact_rides = rides.select(
    "ride_id",
    "driver_id",
    "rider_id",
    "requested_at",
    "status",
    "pickup_lat",
    "pickup_lng",
    "dropoff_lat",
    "dropoff_lng"
)

# Ensure all rides referenced by payments exist
missing_rides = payments.select("ride_id").distinct().join(fact_rides, "ride_id", "left_anti")
if missing_rides.count() > 0:
    ride_placeholders = (
        missing_rides
        .withColumn("driver_id", lit("Unknown"))
        .withColumn("rider_id", lit("Unknown"))
        .withColumn("requested_at", lit(None).cast("timestamp"))
        .withColumn("status", lit("Unknown"))
        .withColumn("pickup_lat", lit(None).cast("double"))
        .withColumn("pickup_lng", lit(None).cast("double"))
        .withColumn("dropoff_lat", lit(None).cast("double"))
        .withColumn("dropoff_lng", lit(None).cast("double"))
    )
    fact_rides = fact_rides.union(ride_placeholders).dropDuplicates(["ride_id"])

fact_payments = payments.select(
    "payment_id",
    "ride_id",
    "amount",
    "currency",
    "method",
    "paid_at"
)

# ---------- Write facts last ----------
write_table(fact_rides, "gold.fact_rides")
write_table(fact_payments, "gold.fact_payments")

print("🎉 Gold star schema built successfully (all 4 tables).")

