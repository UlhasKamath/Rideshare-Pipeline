import argparse, json, random, time, uuid
from datetime import datetime, timezone
from faker import Faker
from kafka import KafkaProducer

def iso_now():
    return datetime.now(timezone.utc).isoformat()

def main(broker, rate):
    fake = Faker()
    producer = KafkaProducer(
        bootstrap_servers=[broker],
        value_serializer=lambda v: json.dumps(v).encode("utf-8")  # JSON serializes floats correctly
    )

    # Create 50 drivers
    drivers = [{
        "driver_id": f"D{1000+i}",
        "driver_name": fake.name(),
        "car_model": random.choice(["Toyota Prius", "Honda City", "Hyundai i20", "Tesla Model 3"]),
        "is_active": True,
        "updated_at": iso_now()
    } for i in range(50)]

    # Create 200 riders
    riders = [{
        "rider_id": f"U{2000+i}",
        "rider_name": fake.name()
    } for i in range(200)]

    # Send initial driver data
    for d in drivers:
        producer.send("drivers", d)

    ride_statuses = ["requested", "accepted", "enroute", "completed", "cancelled"]

    print(f"Producing events to broker {broker} at ~{rate} ride(s)/sec. Ctrl+C to stop.")
    try:
        while True:
            d = random.choice(drivers)
            r = random.choice(riders)

            city_coords = [
                (12.9716, 77.5946),
                (28.6139, 77.2090),
                (19.0760, 72.8777),
                (17.3850, 78.4867),
            ]
            base_lat, base_lng = random.choice(city_coords)
            jitter = lambda: random.uniform(-0.05, 0.05)

            # Produce ride event
            ride = {
                "ride_id": f"R{uuid.uuid4().hex[:10]}",
                "rider_id": r["rider_id"],
                "rider_name": r["rider_name"],
                "driver_id": d["driver_id"],
                "pickup_lat": base_lat + jitter(),
                "pickup_lng": base_lng + jitter(),
                "dropoff_lat": base_lat + jitter(),
                "dropoff_lng": base_lng + jitter(),
                "requested_at": iso_now(),
                "status": random.choice(ride_statuses)
            }
            producer.send("rides", ride)

            # Produce payment event if ride completed
            if ride["status"] == "completed" and random.random() < 0.7:
                amount = round(random.uniform(80, 800), 2)  # Float, not string
                payment = {
                    "payment_id": f"P{uuid.uuid4().hex[:10]}",
                    "ride_id": ride["ride_id"],
                    "amount": amount,               # float → numeric in Postgres
                    "currency": "INR",
                    "method": random.choice(["card", "upi", "cash", "wallet"]),
                    "paid_at": iso_now()
                }
                producer.send("payments", payment)

            # Randomly update driver status
            if random.random() < 0.05:
                d["is_active"] = random.choice([True, False])
                d["updated_at"] = iso_now()
                producer.send("drivers", d)

            producer.flush()
            time.sleep(1.0 / max(rate, 1))

    except KeyboardInterrupt:
        print("Stopped producing events.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--broker", default="kafka:9092", help="Kafka bootstrap server (host:port)")
    parser.add_argument("--rate", type=float, default=2.0, help="rides per second")
    args = parser.parse_args()
    main(args.broker, args.rate)
