
# #!/usr/bin/env bash
# set -e
# echo "Creating Kafka topics: rides, drivers, payments"
# docker exec kafka /opt/bitnami/kafka/bin/kafka-topics.sh --create --if-not-exists --topic rides --bootstrap-server kafka:9092 --partitions 3 --replication-factor 1
# docker exec kafka /opt/bitnami/kafka/bin/kafka-topics.sh --create --if-not-exists --topic drivers --bootstrap-server kafka:9092 --partitions 3 --replication-factor 1
# docker exec kafka /opt/bitnami/kafka/bin/kafka-topics.sh --create --if-not-exists --topic payments --bootstrap-server kafka:9092 --partitions 3 --replication-factor 1
# echo "Done."

#!/bin/bash
set -e
echo "Creating Kafka topics: rides, drivers, payments"

KAFKA_BIN=/opt/bitnami/kafka/bin/kafka-topics.sh
$KAFKA_BIN --create --if-not-exists --topic rides --bootstrap-server kafka:9092 --partitions 3 --replication-factor 1
$KAFKA_BIN --create --if-not-exists --topic drivers --bootstrap-server kafka:9092 --partitions 3 --replication-factor 1
$KAFKA_BIN --create --if-not-exists --topic payments --bootstrap-server kafka:9092 --partitions 3 --replication-factor 1

echo "Done."
